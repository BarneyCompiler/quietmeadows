import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# Load images and music
background_image = pygame.image.load("background.png")
logo_image = pygame.image.load("QuietMeadows.png")
player_image = pygame.image.load("player.png")
world_image = pygame.image.load("world.gif")

# Load music track
pygame.mixer.init()
pygame.mixer.music.load("music.mp3")
pygame.mixer.music.play(-1)

# Set the window title
pygame.display.set_caption("Quiet Meadows BETA 1.4.2")

# Create a font for the button text
font = pygame.font.Font(None, 36)

# Button properties
button_width = 150
button_height = 50
button_x = (screen_width - button_width) // 2
button_y1 = logo_image.get_height() + 10

# Button state
button_hovered1 = False

# Game variables
game_started = False
player_x, player_y = screen_width // 2, screen_height // 2
player_speed = 0.2

world_x = 0
world_y = 0

# World dimensions
world_width = world_image.get_width()
world_height = world_image.get_height()

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                game_started = True

    if not game_started:
        # Display background image
        screen.blit(background_image, (0, 0))

        # Display logo image
        screen.blit(logo_image, ((screen_width - logo_image.get_width()) // 2, 10))

        # Draw the "Start Game" button
        mouse_x, mouse_y = pygame.mouse.get_pos()
        button_hovered1 = (
            button_x < mouse_x < button_x + button_width and button_y1 < mouse_y < button_y1 + button_height
        )

        if button_hovered1:
            pygame.draw.rect(screen, (255, 255, 255), (button_x, button_y1, button_width, button_height))
        else:
            pygame.draw.rect(screen, (0, 0, 0), (button_x, button_y1, button_width, button_height))

        text1 = font.render("Play", True, (0, 0, 0) if button_hovered1 else (255, 255, 255))
        text_x1 = button_x + (button_width - text1.get_width()) // 2
        text_y1 = button_y1 + (button_height - text1.get_height()) // 2
        screen.blit(text1, (text_x1, text_y1))
    else:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            player_y -= player_speed
        if keys[pygame.K_s]:
            player_y += player_speed
        if keys[pygame.K_a]:
            player_x -= player_speed
        if keys[pygame.K_d]:
            player_x += player_speed

        # Limit player movement within the world bounds
        player_x = max(0, min(player_x, world_width - player_image.get_width()))
        player_y = max(0, min(player_y, world_height - player_image.get_height()))

        # Calculate the world scroll offsets
        world_x = min(max(0, player_x - screen_width // 2), world_width - screen_width)
        world_y = min(max(0, player_y - screen_height // 2), world_height - screen_height)

        # Clear the screen
        screen.fill((0, 0, 0))

        # Draw the visible portion of the world
        screen.blit(world_image, (0, 0), (world_x, world_y, screen_width, screen_height))
        screen.blit(player_image, (player_x - world_x, player_y - world_y))

    pygame.display.flip()

pygame.quit()
sys.exit()
